package com.olik.assignments;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OlikPracticeApplication {

	public static void main(String[] args) {
		SpringApplication.run(OlikPracticeApplication.class, args);
	}

}

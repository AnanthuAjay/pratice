package com.olik.assignments;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OlikPracticeApplicationTests {

	@Test
	void contextLoads() {
	}

}
